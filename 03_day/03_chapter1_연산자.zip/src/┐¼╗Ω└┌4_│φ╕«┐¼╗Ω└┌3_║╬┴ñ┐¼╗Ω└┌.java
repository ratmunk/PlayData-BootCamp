
public class 연산자4_논리연산자3_부정연산자 {

	public static void main(String[] args) {
	
		// 논리연산자 : ==> && (앰퍼샌트),  || , !(부정연산자)
		/*
			 3. ! ( 부정연산자)
			 
			      !논리값
			 	 !true => false
			 	 !false => true

			 예>
			  
                !(3==4) && 논리값 || 논리값
     	 */
	
		System.out.println(!true); // false
		System.out.println(!false); // true
		
	}
}
