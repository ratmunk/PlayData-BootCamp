
public class PDT2_실수범위 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("float최소값:"+Float.MIN_VALUE);
		System.out.println("float최대값:"+Float.MAX_VALUE);
		
		System.out.println("double최소값:"+Double.MIN_VALUE);
		System.out.println("double최대값:"+Double.MAX_VALUE);
	}

}
