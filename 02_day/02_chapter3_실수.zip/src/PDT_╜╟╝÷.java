
public class PDT_실수 {

	public static void main(String[] args) {
		// 실수 ( float:4byte, double:8byte)
		
		//1. float 표현
		System.out.println(3.14F);
		System.out.println(3.14f);
		
		//2. double 표현
		System.out.println(3.14D);
		System.out.println(3.14d);
		System.out.println(3.14);

	}

}
