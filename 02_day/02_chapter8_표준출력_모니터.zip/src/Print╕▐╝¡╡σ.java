
public class Print메서드 {

	public static void main(String[] args) {
		// 모니터에 출력하는 표준출력 방법
		/*
		 *  1. System.out.println(값)
		 *    ==> 새로운 라인을 생성하고 출력한다.
		 *  2. System.out.print(값)
		 *    ==> 새로운 라인을 생성하지 않고 출력한다.
		 *       따라서 한 줄에 출력된다.
		 * 
		 */

		//2. System.out.print(값)
		System.out.print("1");
		System.out.print("2\n");
//		System.out.println();
		System.out.print("3");
		System.out.print(100);
		
		
		
	}

}
