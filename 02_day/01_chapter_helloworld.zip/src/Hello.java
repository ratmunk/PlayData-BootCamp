
public class Hello {

	// main 메서드
	public static void main(String[] ccc) {
		// 주석문
		System.out.println("Hello World");
		System.out.println("인경열");
		System.out.println(22);
		System.out.println('남');
		System.out.println(true); //false
		System.out.println(173.6); 
		System.out.println(""+null); // 값이 없음 의미
	
	}

}
