
public class PDT2_escape문자 {

	public static void main(String[] args) {
		// escape 문자 ==> 특별한 기능을 구현한다
		
		System.out.println("Helloworld");
		System.out.println("Hello	world");// TAB 1번
		System.out.println("Hello   world");//spacebar 3번
		System.out.println("Hello\tworld");
		System.out.println("Hello\nworld");
		System.out.println("Hello\"world");
		System.out.println("Hello\'world");
		//파일경로   c:\aaa
		System.out.println("c:\\aaa");

	}

}
