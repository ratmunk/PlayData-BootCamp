
public class PDT_char {

	public static void main(String[] args) {
		//char 정리
		// 하나의 문자 표현=> char(캐릭터) 타입
		System.out.println('A');
		System.out.println('홍');
		
		// 여러개의 문자표현 ==> 문자열, String 타입
		System.out.println("홍길동");
		
	}
}
